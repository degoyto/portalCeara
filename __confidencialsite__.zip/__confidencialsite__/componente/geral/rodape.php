<footer class="container-flex footer">
    <div class="container rodape">
        <div class="linksRodape">
            <a href='noticias'>municípios</a>

            <a href='/noticias'>notícias</a>
            <a href='/eventos'>eventos</a>
            <a href='noticias'>classificados</a>
            <a href='/contato'>Contato</a>
        </div>
        <div class='outroRodape'>
            Copyright  PORTAL DO CEARÁ 2020. Todos os direitos reservados.
        </div>
        
    </div>
    
</footer>