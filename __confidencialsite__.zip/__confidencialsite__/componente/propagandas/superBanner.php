<div class="container-flex">
    <div class="container superBanner">
        <a href="https://www.jornalportodopecem.com.br">
            <img class="imgPropaganda" src="https://firebasestorage.googleapis.com/v0/b/o-portal-do-ceara.appspot.com/o/propagandas%2FportoPecemSuperBanner.jpg?alt=media&token=e98759b3-e912-4195-99c6-e250840a30e8"/>
        </a>
        
    </div>

</div>