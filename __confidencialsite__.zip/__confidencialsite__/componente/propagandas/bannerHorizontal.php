<div class="container-flex">
    <div class="container bannerHorizontal">
        <p> Anuncie Aqui</p>
    </div>

</div>