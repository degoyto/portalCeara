<div class="container-flex">
    <div class="container bannerPequeno">
        <p> Anuncie Aqui</p>
    </div>

</div>