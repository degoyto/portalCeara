<div class="container-flex">
<h1 class="tituloContato"> Contato</h1>
    <div class="contato container">
        
        <div class='textoContato'>
            <div class="contatos">
                <h2>O Portal do Ceará:</h2>
                <p>
                    contato@oportaldoceara.com.br
                </p>
            </div>
            <div class="contatos">
                <h2>Redação:</h2>
                <p>
                    redacao@oportaldoceara.com.br
                </p>
            </div>
            <div class="contatos">
                <h2>Suporte Técnico:</h2>
                <p>
                    suporte@oportaldoceara.com.br
                </p>
            </div>
            <div class="contatos">
                <h2>Comercial:</h2>
                <p>
                    comercial@oportaldoceara.com.br
                </p>
            </div>
        
        </div>
        <div class='imagemContato'>
            <img src="https://firebasestorage.googleapis.com/v0/b/o-portal-do-ceara.appspot.com/o/outros%2FLOGO%20(1).png?alt=media&token=045729e0-207a-401f-9171-e70ea5852330"/>

        </div>
        
    

        
    </div>

</div>