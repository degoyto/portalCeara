var anterior = 0;

function selecionado(recebido){
    
    if (anterior === 0){
        document.getElementById(recebido.id).classList.remove("st7");
        document.getElementById(recebido.id).classList.add("st8");
    }
    else{
        document.getElementById(anterior).classList.remove("st8");
        document.getElementById(anterior).classList.add("st7");

        document.getElementById(recebido.id).classList.remove("st7");
        document.getElementById(recebido.id).classList.add("st8");
    }
    anterior = recebido.id;
    
}

function mudarCor(recebido){
    document.getElementById(recebido.id).classList.remove("st7");
    document.getElementById(recebido.id).classList.add("st8");
}

function voltarCor(recebido){
    document.getElementById(recebido.id).classList.remove("st8");
    document.getElementById(recebido.id).classList.add("st7");
}