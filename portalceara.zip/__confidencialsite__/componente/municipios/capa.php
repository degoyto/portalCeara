<?php 
    $linkFoto = $exibe['foto'];

?>
<!DOCTYPE html>
<div class="container-flex" id="inicio" >
    <div id="textoCapa" class="textosCapa" style="background-image:url('<?php echo $linkFoto?>')">
        <div class="container titulo">
            <h1> <?php echo $exibe['nome'] ?></h1> 
        </div>
        
    </div>
    
        
</div>

