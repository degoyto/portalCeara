<div class="noticiasCidade container">
    
    <h1>Últimas Notícias</h1>
    
    <div class="divNoticias">
        <?php 
            $numero = 0;
            while ($numero<10){
                echo "<div class='cadaNoticia'>
                <div class='imgNoticia'>
    
                </div>
                <h2>Título".$numero."</h2>
            </div>";
            $numero++;
            }
        ?>
        
        
        
    </div>

</div>