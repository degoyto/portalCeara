<div class="container-flex divMissao divDestaque" id="destaques">

    <h1>Municípios em Destaque</h1>
    <div class="container mapaCidade">
        <div class="mapSvg">
            <?php include("mapaID.html") ?>
            
        </div>
        <div class="missaoTexto">
            <?php include("cidadesDestaque/cidades.php") ?>
        </div>
    </div>
</div>